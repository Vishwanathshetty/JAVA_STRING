package com.wipro.strings;

import java.util.Arrays;
import java.util.Scanner;

public class Question_9 {
	
	//Program to sort the string and extracting odd positioned characters

	public static void main(String[] args) {
		
		// Initialization of scanner class
		Scanner scan =new Scanner(System.in);
				
		//Taking the input from the user
		System.out.println("Enter a string:");
		String str=scan.nextLine();
		
		// finding length of the string s
		int len=str.length();
	
		//Creating two strings to store sorted string and to store character at odd position
		String sort="";
		String s="";
		
		//converting string to character array.
		char[] ch=str.toCharArray();
		
		//sorting an array
		Arrays.sort(ch);
		
		//checking for odd position and storing the characters in odd position, in a string
		for(int i=0;i<len;i++)
		{
			if(i%2!=0)
				sort=sort+ch[i];
			s=s+ch[i];
		}
		
		//printing sorted string and odd positioned character string.
		System.out.println("Sorted string is: "+s);
		System.out.println("Odd positioned character string is: "+ sort);
		
		scan.close();
	}
	
}
