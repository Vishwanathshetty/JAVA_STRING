package com.wipro.strings;

import java.util.Scanner;

public class Question_8 {

	//program to find the maximum and minimum occurred character in a String
	
	public static void main(String[] args) {
		
		// Initialization of scanner class
		Scanner scan =new Scanner(System.in);
				
		//Taking the input from the user
		System.out.println("Enter a string:");
		String str=scan.nextLine();
		
		// finding length of the string s
		int len=str.length();
		
		//initializing one array to store the count
		int[] count=new int[len];
		
		//converting string to character array.
		char[] ch=str.toCharArray();
		
		//counting the occurrence of each character
		for(int i=0;i<len;i++)
		{
			count[i]=1;
			for(int j=i+1;j<len;j++)
			{
				if(ch[i]==ch[j] && ch[i]!=' ' && ch[i]!='0')
				{
					count[i]++;
					//setting the counted character to zero
					ch[j]='0';
				}
			}
		}
			
		//'min' and 'max' variable set to first count
		int min=count[0];
		int max=count[0];
		
		//looping the count array and finding the minimum and maximum value present in it
		for(int i=0;i<len;i++)
		{
			if(count[i]<min)
				min=count[i];
			
			if(count[i]>max)
				max=count[i];
		}	
		
		
		//looping the character array and printing all the character with min and max occurrence
		System.out.print("The minimum occured character/s is/are: " );
		for(int i=0;i<len;i++)
			if(count[i]==min && ch[i]!='0' && ch[i]!=' ')
				System.out.print(ch[i]+" ");
		System.out.println("and occured "+min+" times");
		
		System.out.println();
		
		System.out.print("The maximum occured character/s is/are: " );
		for(int i=0;i<len;i++)
			if(count[i]==max && ch[i]!='0'&& ch[i]!=' ')
				System.out.print(ch[i]+" ");
		System.out.println("and occured "+max+" times");
		
		scan.close();
	}

}
