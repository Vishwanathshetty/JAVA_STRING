package com.wipro.strings;

import java.util.Scanner;

public class Question_10 {

	public static void main(String[] args) {
		
		// Initialization of scanner class
		Scanner scan =new Scanner(System.in);
						
		//Taking the input from the user
		System.out.println("Enter a string:");
		String str=scan.nextLine();
				
		// finding length of the string s
		int len=str.length();
		
		//declaring a variable to store the alphabetical index of last character of a string
		//Assuming A=1 B=2 C=3 etc
		int last=0;
		
		if(Character.isUpperCase(str.charAt(len-1)))
			last=str.charAt(len-1)-64;
		
		if(Character.isLowerCase(str.charAt(len-1)))
			last=str.charAt(len-1)-96;
		
		//calculating the age of a string
		int age=len+last;
		
		//Printing the age of a string
		System.out.println("Age of the string is: " + age);

		scan.close();
	}

}
