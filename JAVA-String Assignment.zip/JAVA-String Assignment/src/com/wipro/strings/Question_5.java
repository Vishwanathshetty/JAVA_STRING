package com.wipro.strings;

import java.util.Scanner;

public class Question_5 {

	//Program to toggle the string
	
	public static void main(String[] args) {
		
		// Initialization of scanner class
		Scanner scan =new Scanner(System.in);
				
		//Taking the input from the user
		System.out.println("Enter a string:");
		String str=scan.nextLine();
		
		//finding the length of the string
		int len=str.length();
		
		//initializing a empty string to store toggled string
		String togg="";
		
		//toggling the string
		for(int i=0;i<len;i++)
		{
			if(Character.isUpperCase(str.charAt(i)))
				togg=togg+Character.toLowerCase(str.charAt(i));
			else if(Character.isLowerCase(str.charAt(i)))
				togg=togg+Character.toUpperCase(str.charAt(i));
			else
				togg=togg+str.charAt(i);
		}
		
		//printing the toggled string
		System.out.println("Toggled String is: "+ togg);
		
		scan.close();
	}

}
