package com.wipro.strings;

import java.util.Scanner;

public class Question_2 {
	
	//Program to count upper case and lower case character in a string

	public static void main(String[] args) {
		//initializing two counter element to count upper case and lower case character
		int up_count=0;
		int low_count=0;
		
		// Initialization of scanner class
		Scanner scan =new Scanner(System.in);
		
		//Taking the input from the user
		System.out.println("Enter a string:");
		String str=scan.nextLine();
		
		//finding the length of the string
		int len=str.length();
		
		//looping and checking whether a character is in upper case or in lower case
		for(int i=0;i<len;i++)
		{
			if(Character.isUpperCase(str.charAt(i)))
					up_count++;
			else if(Character.isLowerCase(str.charAt(i)))
					low_count++;
			else
				continue;
		}
		
		//checking whether counts are equal or not
		
		if(up_count==low_count)
			System.out.println("Equally Distributed");
		else
		{
			System.out.println("Uppercase count is: "+ up_count);
			System.out.println("Lowercase count is: "+ low_count);
		}
		
		scan.close();
		
	}
}
