package com.wipro.strings;

import java.util.Scanner;

public class Question_7 {

	//Program to merge the two string, character by character
	
	public static void main(String[] args) {
		// Initialization of scanner class
		Scanner scan=new Scanner(System.in);
				
		//Taking the input from the user
		System.out.println("Enter String S1: ");
		String s1=scan.nextLine();
		System.out.println("Enter String S2: ");
		String s2=scan.nextLine();
		
		//creating an empty string to store the output
		String op="";
		
		// finding length of the string s1 and s2
		int len1=s1.length();
		int len2=s2.length();
		
		//checking the length and merging
		if(len1<=len2)
		{
			for(int i=0;i<len1;i++)
				op=op+s1.charAt(i)+s2.charAt(i);
			
			op=op+s2.substring(len1, len2);
		}
		
		if(len2<len1)
		{
			for(int i=0;i<len2;i++)
				op=op+s1.charAt(i)+s2.charAt(i);
			
			op=op+s1.substring(len2, len1);
		}
		
		//printing the merged string
		System.out.println("Merged String is: "+ op);
		
		
		scan.close();
	}

}
