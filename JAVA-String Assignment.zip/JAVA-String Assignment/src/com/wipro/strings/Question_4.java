package com.wipro.strings;

import java.util.Arrays;
import java.util.Scanner;

public class Question_4 {
	
	//Program to split the string and arranging in dictionary order

	public static void main(String[] args) {
		
		// Initialization of scanner class
		Scanner scan =new Scanner(System.in);
						
		//Taking the input from the user
		System.out.println("Enter a line:");
		String str=scan.nextLine();
				
		//splitting the string using split() function
		String[] strings=str.split(" ");
		
		//sorting 'strings' array
		Arrays.sort(strings);
		
		//printing the splitted strings in dictionary order
		System.out.println("Dictionary order");
		for(int i=0;i<strings.length;i++)
			System.out.println(strings[i]);
				
		scan.close();
	}

}
