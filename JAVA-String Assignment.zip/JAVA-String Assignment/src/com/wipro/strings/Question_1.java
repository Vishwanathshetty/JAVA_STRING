package com.wipro.strings;

import java.util.Scanner;

public class Question_1 {

	//Program to Reverse a string 
	
	public static void main(String[] args) {
		
		// Initialization of scanner class
		Scanner scan=new Scanner(System.in);
		
		//Taking the input from the user
		System.out.println("Enter String S: ");
		String s=scan.nextLine();
		System.out.println("Enter String S1: ");
		String s1=scan.nextLine();
		
		// finding length of the string s
		int len=s.length();
		
		//initializing a empty string to hold the value of reversed string
		String rev="";
		
		//checking string equality
		if(s.equals(s1))
		{
			for(int i=len-1;i>=0;i--)
				rev=rev+s.charAt(i);
			
			//printing reversed string
			System.out.println("Reversed string is: " + rev);
		}
		
		//if strings are not equal
		else
			System.out.println("Reverse Not Supported");
		
		scan.close();
	}
}
