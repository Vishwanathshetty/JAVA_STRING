package com.wipro.strings;

import java.util.Scanner;

public class Question_6 {
	
	//Program to Rotate a string based on its length(even or odd), If even clockwise, if odd anti 
	//clockwise
	
	public static void main(String[] args) {
		// Initialization of scanner class
		Scanner scan =new Scanner(System.in);
						
		//Taking the input from the user
		System.out.println("Enter a string:");
		String str=scan.nextLine();
				
		//finding the length of the string
		int len=str.length();
		
		//using string buffer to rotate the string
		StringBuffer rot=new StringBuffer(str);
		
		//checking whether length is even or odd and rotating accordingly
		
		if(len%2==0)
		{
			rot.insert(0,str.charAt(len-1));
			rot.delete(rot.length()-1,rot.length());
			
		}
		
		else
		{
			rot.insert(len,str.charAt(0));
			rot.deleteCharAt(0);
		}
			
		//printing the rotated string
		System.out.println(rot);
		
		scan.close();
		
	}

}
