package com.wipro.strings;


import java.util.Scanner;

public class Question_3 {
	
	//program to split a string and printing string with smallest length
	
	public static void main(String args[])
	{
		// Initialization of scanner class
		Scanner scan =new Scanner(System.in);
				
		//Taking the input from the user
		System.out.println("Enter a line:");
		String str=scan.nextLine();
		
		//splitting the string using split() function
		String[] strings=str.split(" ");
		
		//looping the 'strings' array and finding their length and string it in one array
		int[] a=new int[strings.length];
		for(int i=0;i<strings.length;i++)
			a[i]=strings[i].length();
		
		//assigning first element of array to a variable 'min'
		int min=a[0];
	
		//looping the array 'a' and finding the minimum length
		for(int j=0;j<a.length;j++)
			if(a[j]<min)
				min=a[j];
		
		//printing the strings with minimum length
		System.out.println("String/Strings with smallest length is/are: ");
		
		for(int k=0;k<a.length;k++)
			if(a[k]==min)
				System.out.println(strings[k]);
		
		scan.close();
	}

}
